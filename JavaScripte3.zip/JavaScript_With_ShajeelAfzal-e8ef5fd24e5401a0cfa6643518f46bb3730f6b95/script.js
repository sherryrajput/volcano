document.write("<h1>Hello World from External JS!</h1>");
// alert("This is the dialog box!"); 

// this show alert

/*

	This is multiline comment.

*/

var z;
z = 100;
var x = 10;
var X = 20;
// var first name; (invalid variable name)
// var 0firtstName; (invalid variable name)
// var first0Name; (valid variable name)
// var _firstName; (valid variable name)
// var $firstName; (valid variable name)
// var x+y; (invalid variable name)

/*
	
	1- variables names cannot contain spaces
	2- variables cannot start with a number
	3- researved words cannot be used
	4- variable names can start with any letter, 
	   underscore ( _ ) or a dollar sign ($)
	5- Subsequent characters maybe letters, digits,
	   underscore, or dollar signs.    

*/

document.write(X);

var sayHello = "<br>\'Hello World!\'";

// \n new line
// \r cariage return
// \t tab

document.write(sayHello);

var isActive = true;
var isHoliday = false;

// +, -, *, /, %, ++, --

document.write("<br><br>");

var i = 19;

i++;

document.write(--i);
document.write("<br><br>");
document.write(i);













