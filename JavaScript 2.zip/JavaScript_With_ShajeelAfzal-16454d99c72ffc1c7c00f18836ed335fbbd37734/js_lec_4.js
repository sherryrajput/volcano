/*

condition can be any statement 
but it should return true or false
while(condition){
	code block
}

*/

// var i=0;
// while(i<5){
// 	document.write("<br>While Loop");
// 	i++;
// }

// while(1){
// 	document.write("<br>While Loop");	
// }

// var x = 1;
// do{
// 	document.write("Do While Loop<br>");
// }while(x <= 5);

// var z = 0;
// while(true){
// 	document.write("Do While Loop<br>");
// 	z++;
// 	if (z > 10) {
// 		break;
// 	}	
// }`

// for(var i=0; i < 5; i++){
// 	if (i == 3) {
// 		continue;
// 	}

// 	document.write("Continue statement");
// }

// function doCalculation(){
// 	var x = 10;
// 	var y = 20;
// 	document.write(x+y);
// 	document.write("<br>");
// }

// doCalculation();
// doCalculation();

// function doCalculation(x, y){
// 	document.write(x+y);
// 	document.write("<br>");

// 	return x+y;
// }

// var sum = doCalculation(50, 20);
// doCalculation(50.5, 20);

// var result = confirm("Are you to delete?");
// if (result==true) {
// 	alert("OK Selected");
// } else {
// 	alert("Cancel Selected");
// }

var name = prompt("Enter your name");















