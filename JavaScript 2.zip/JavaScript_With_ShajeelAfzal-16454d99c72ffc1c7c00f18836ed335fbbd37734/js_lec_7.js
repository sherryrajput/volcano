var quiz = {
	question: "What is the square root of 100?",
	answers: [
		{answer: "1", url:""},
		{answer: "8", url:""},
		{answer: "10", url:""},
		{answer: "7", url:"IMAGE_URL"}
	],
	correctAnswer: 2,
	help: ["YOUTUBE_URL", "TITLE"]

	// changeCorrectAnswer: function(answerId){
	// 	this.correctAnswer = answerId;
	// }
};

document.write(quiz.question);
if (quiz.answers[3].url == "") {
	// hide the image tag
} else {
	// show the image tag
};

if (quiz.answers[0].url == "") {
	// hide the image tag
} else {
	// show the image tag
};

if (quiz.answers[1].url == "") {
	// hide the image tag
} else {
	// show the image tag
};

if (quiz.answers[2].url == "") {
	// hide the image tag
} else {
	// show the image tag
};

/*
objectName.methodName();
document.write();
*/

// method: function(){
// 	code
// }

// var car = {
// 	buildDate: 2015,
// 	color: "blue",
// 	model: 2017,
// 	engine: "1300cc",
// 	abc: ["item1", "item2"],
// 	owner: {
// 		name: "Jhon",
// 		age: 26,
// 		education: "Masters"
// 	}
// };





